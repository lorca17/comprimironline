=== WP All Backup ===
Contributors: Prashant Walke
Donate link: http://www.wpseeds.com/product/wp-all-backup/
Tags: back up, backup, backups, database, zip, db, files, archive, dropbox,email,restore, Database backup,db backup ,backup, WordPress Database Backup, WP db backup,wp database backup,wp backup, wordpress backup, mysql backup,automatically database backup,website backup,website database backup,restore backup
Requires at least: 3.3.3
Tested up to: 4.5

WP All Backup plugin helps you to create Backup and Restore Backup easily on single click.Manual or Automated Backups And also store backup on safe place- dropbox,FTP.

== Description ==

<p>WP All Backup plugin helps you to create Backup and Restore Backup easily on single click.Manual or Automated Backups And also store backup on safe place- dropbox,FTP.</p>

<p>Creates a Backup of your entire website: that's your Database, current WP Core, all your Themes, Plugins and Uploads.</p>

= Features =
<ul>
<li>Create Database Backup easily on single click. </li>
<li>Autobackup Backup automatically on a repeating schedule</li> 
<li>Backup Listing : Pagination.</li>
<li>Manual backup</li> 
<li>Multisite compatible</li> 
<li>Backup entire site</li>
<li>Exclude specific folders and files</li> 
<li>Downloadable log files</li> 
<li>Simple one-click restore</li> 
<li>Set number of backups to store</li>
<li>Automatically remove oldest backup</li>
<li>FTP integration</li>
<li>Dropbox integration</li> 
<li>Email Notification</li>
<li>ZipArchive</li>
<li>Select Backup Type: Only Database,Only Files, Complete Backup</li>
<li>Inline Help</li>
<li>Search backup from list(Date/Size)</li>
<li>Sort backup list (Date/Size)</li>
<li>Easy To Install(Very easy to use)</li>
<li>Simple to configure(very less configuration).</li>
</ul>
<p><a href="http://www.wpseeds.com/product/wp-all-backup/" target="_blank">Get Pro 'WP All Backup' Plugin</a></p>
<ul>
<li>Support</li>
<li>Updates</li>
<li>Uses zip and mysqldump for faster back ups if they are available.</li>
<li>Exclude Tables from your back ups.</li>
<li>System Check (i.e backup folder permission, execution time etc)</li>
<li>PclZip</li>
<li>Clone Site</li>
<li>Move Site</li>
<li>Change Backup folder name</li>
<li>And More....</li>
</ul>

== Installation ==
1. Download the plugin file, unzip and place it in your wp-content/plugins/ folder. You can alternatively upload it via the WordPress plugin backend.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. WP ALL Backup menu will appear in Dashboard->WP ALL Backup. Click on it & get started to use.
4. Refer to the for <a href=" http://www.wpseeds.com/wp-all-backup/">More Information</a>.

== Screenshots ==

wp_all_backup_create_backup.png
wp_all_backup_setting.png
wp_all_backup_setting_schedule.png

Refer to the for <a href=" http://www.wpseeds.com/wp-all-backup/">Screenshots and More Information</a>.

== Changelog ==

= 2.7.1 =
* Fixed : Resolved installer issue

= 2.6 = 
* Added : Select Individual file and directory filters in Exclude setting
* Added :  Enable/Disable .htaccess File In Storage Directory seeting

= 2.4 = 
* Resolved : Time out issue

= 2.3 = 
* Resolved error : headers already sent - plugin activation

= 2.2 = 
* Released on : 14-04-2016
* Update exclude files and folders rule.
* Backup zip labeled with the site name(Help when backing up multiple sites).
* Compatible wordpress version 4.5 : Depricated function : mysql_real_escape_string. use _real_escape insted mysql_real_escape_string
* Resolved issue : PHP Strict Standards:  mktime(). use the time() function instead mktime().

= 1.0.0 = 
* Plugin Created

== Frequently Asked Questions ==

 Q-How to  create database Backup?
 <br>Follow the steps listed below to Create Backup

 <br>Create Backup:
  <br>1) Click on Create New Backup
  <br>2) Download Database Backup file.
  
 Q-How to restore database backup?
  <br>Restore Backup:
  <br>Click on Restore  
   
 Q-Always get an empty (0 bits) backup file?
 <br>Ans-This is generally caused by an access denied problem.
 <br>You don't have permission to write in the wp-content/uploads. 
 <br>Please check if you have the read write permission on the folder.
 
 Q.want more featur?
 If you want more feature then
 Drop Mail :walke.prashant28@gmail.com
  
== Upgrade Notice ==
=2.7.1 =
Fixed issues

== Official Site ==
For <a href="walkeprashant.wordpress.com/wp-all-backup/">More Information</a> Or Advanced feature drop mail:walke.prashant28@gmail.com
